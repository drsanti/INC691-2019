export default {
    input: 'src/cg-scene.js',
    output: {
        file: 'src/build/ecc-cg-scene.merged.js',
        name: 'ecc-cg-scene',
        format: 'esm'
      }
  };

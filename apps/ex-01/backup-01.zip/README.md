INC691-2019
- Modern Front-end development using CG+VR+AR technologies
- Modern Back-end development based on node.js
